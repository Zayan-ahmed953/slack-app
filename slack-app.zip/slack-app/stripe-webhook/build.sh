#!/bin/bash

green=`tput setaf 2`
yellow=`tput setaf 3`
reset=`tput sgr0`

echo -e "${yellow}\n - Installing node modules...${reset}" && \
yarn install && \

echo -e "${yellow}\n - Preparing zip package..." ${reset} && \
mkdir -p ./dist/package/ && \
find . -name '*.js' | grep -v ./node_modules/ | cpio --quiet -updm ./dist/package/ && \
cp -fpR node_modules ./dist/package/ && \
cd ./dist/package/ && zip -q -r ../package.zip * && \
cd ../ && rm -rf ./package/ && \
echo -e "${green}\n - Done! Deployment package ready at ./dist/package.zip\n${reset}"
