const InstallationService = require('../services/installation');
const SubscriptionService = require('../services/subscription');

const { segmentClient, Bugsnag } = require('../analytics');

async function attachInstallationDetails({ payload, client, context, next }) {
  try {
    let installation = await InstallationService.findInstallation({
      enterpriseId: context.enterpriseId,
      teamId: context.teamId,
    });

    if (!installation.subscription.customerId) {
      installation = await SubscriptionService.createStripeCustomer({ installation });
    }

    context.installation = installation;
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
  await next();
}

async function attachUserDetails({ payload, client, context, body, next }) {
  try {
    // For most events Slack returns the users Id in payload as user.id
    // For Commands payload.user_id gives the Id
    // For Home Event payload.user gives the Id
    // For Views Listener Event, we retrieve it from the Body
    let userId = payload?.user?.id
      ? payload.user.id
      : payload?.user_id
      ? payload.user_id
      : payload?.user
      ? payload.user
      : body?.user?.id
      ? body.user.id
      : null;

    if (!userId) {
      throw new Error('user id not defined');
    }

    // const userInfo = await client.users.info({ user: userId });
    // context.currentUser = userInfo.user;

    if (!context.installation.isAdminUserSetup) {
      // let adminUser = userInfo.user;
      const adminUserInfo = await client.users.info({ user: context.installation.user.id });
      let adminUser = adminUserInfo.user;

      // if (userId !== context.installation.user.id) {
      //   const adminUserInfo = await client.users.info({ user: userId });
      //   adminUser = adminUserInfo.user;
      // }

      context.installation = await SubscriptionService.setupAdminUserDetails({
        installationId: context.installation._id,
        user: adminUser,
      });
    }

    segmentClient.identify({
      userId: `${context.teamId}-${userId}`,
      traits: {
        isEnterpriseInstall: context.installation.isEnterpriseInstall,
        userId: `${context.teamId}-${userId}`,
        groupId: context.teamId,
        team: context.installation.team.name,
        plan: context.installation.plan,
        images: context.installation.usage.images,
        tokens: context.installation.usage.tokens,
        lifeTimeTokens: context.installation.usage.totalTokensUsed,
        lifeTimeImages: context.installation.usage.totalImagesUsed,
      },
    });

    segmentClient.group({
      userId: `${context.teamId}-${userId}`,
      groupId: context.teamId,
      traits: {
        name: context.installation.team.name,
        plan: context.installation.plan,
        images: context.installation.usage.images,
        tokens: context.installation.usage.tokens,
        lifeTimeTokens: context.installation.usage.totalTokensUsed,
        lifeTimeImages: context.installation.usage.totalImagesUsed,
      },
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
  await next();
}

async function attachPlanDetails({ payload, client, context, next }) {
  try {
    context.planDetails = await SubscriptionService.getPlanDetails({ planName: context.installation.plan });

    context.planDetails.limits.tokens =
      parseInt(context.planDetails.limits.tokens) * parseInt(context.installation.subscription.quantity);
    context.planDetails.limits.images =
      parseInt(context.planDetails.limits.images) * parseInt(context.installation.subscription.quantity);
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
  await next();
}

async function validateUserSubscription({ payload, client, context, ack, next }) {
  try {
    if (payload.type === 'app_home_opened' && payload.tab === 'home') {
      await next();
    }

    if (!context.installation.subscription.isActive) {
      if (context.installation.trialExpired) {
        if (context.installation.plan === 'Free Trial') {
          if (ack !== undefined) {
            await ack();
          }
          throw new Error('Trial Ended');
        } else {
          if (ack !== undefined) {
            await ack();
          }
          throw new Error('Subscription Ended');
        }
      }

      const isTrialRemaining = context.installation.trialEndsOn > Math.floor(Date.now() / 1000);
      if (!isTrialRemaining) {
        context.installation = await SubscriptionService.endUserTrial(context.installation._id);
        if (ack !== undefined) {
          await ack();
        }
        throw new Error('Trial Ended');
      }
    }

    const areTokensRemaining = context.planDetails.limits.tokens > context.installation.usage.tokens;
    const areImagesRemaining = context.planDetails.limits.images > context.installation.usage.images;

    if (!areTokensRemaining && !areImagesRemaining) {
      if (!context.installation.trialExpired) {
        context.installation = await SubscriptionService.endUserTrial(context.installation._id);
        if (ack !== undefined) {
          await ack();
        }
        throw new Error('Reached Plan Limit');
      }
    }

    if (!areTokensRemaining && areImagesRemaining) {
      if (
        ['/intern', '/code'].includes(payload?.command) ||
        ['button_text_regenerate', 'button_code_regenerate'].includes(payload?.action_id) ||
        (payload?.type === 'message' && payload?.channel_type === 'im')
      ) {
        if (ack !== undefined) {
          await ack();
        }
        throw new Error('Used All Tokens');
      }
    }

    if (areTokensRemaining && !areImagesRemaining) {
      if (payload?.command === '/image' || payload?.action_id === 'button_image_regenerate') {
        if (ack !== undefined) {
          await ack();
        }
        throw new Error('Used All Images');
      }
    }
  } catch (error) {
    // For most events Slack returns the users Id in payload as user.id
    // For Commands payload.user_id gives the Id
    // For Home Event payload.user gives the Id
    // For Views Listener Event, we retrieve it from the Body
    let userId = payload?.user?.id
      ? payload.user.id
      : payload?.user_id
      ? payload.user_id
      : payload?.user
      ? payload.user
      : body?.user?.id
      ? body.user.id
      : null;

    const channelId =
      payload.channel_name === 'directmessage'
        ? `@${payload.user_name}`
        : payload.channel
        ? payload.channel
        : payload.channel_id;

    if (error.message === 'Trial Ended') {
      await SubscriptionService.sendActivateSubscriptionMessage({
        client,
        installation: context.installation,
        plan: context.planDetails,
        userId,
        channelId,
        actionId: payload.action_id,
      });
      return;
    }

    if (error.message === 'Subscription Ended') {
      await SubscriptionService.sendActivateSubscriptionMessage({
        client,
        installation: context.installation,
        plan: context.planDetails,
        userId,
        channelId,
        actionId: payload.action_id,
        hasSubscriptionEnd: true,
      });
      return;
    }

    if (error.message === 'Used All Tokens') {
      await SubscriptionService.sendActivateSubscriptionMessage({
        client,
        installation: context.installation,
        plan: context.planDetails,
        userId,
        channelId,
        actionId: payload.action_id,
        reachedLimitOn: 'words',
      });
      return;
    }

    if (error.message === 'Used All Images') {
      await SubscriptionService.sendActivateSubscriptionMessage({
        client,
        installation: context.installation,
        plan: context.planDetails,
        userId,
        channelId,
        actionId: payload.action_id,
        reachedLimitOn: 'images',
      });
      return;
    }

    if (error.message === 'Reached Plan Limit') {
      await SubscriptionService.sendActivateSubscriptionMessage({
        client,
        installation: context.installation,
        plan: context.planDetails,
        userId,
        channelId,
        actionId: payload.action_id,
        reachedLimitOn: 'words and images',
      });
      return;
    }

    // Bugsnag.notify(error);
    console.log(error);
  }

  await next();
}

module.exports = {
  attachInstallationDetails,
  attachUserDetails,
  attachPlanDetails,
  validateUserSubscription,
};
