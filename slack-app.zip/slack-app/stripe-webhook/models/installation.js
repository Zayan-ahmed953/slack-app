const mongoose = require('mongoose');

const SlackInstallation = mongoose.Schema(
  {
    _id: {
      type: mongoose.Schema.Types.ObjectId,
      auto: true,
    },
    team: {
      id: { type: String, default: null },
      name: { type: String, default: null },
    },
    enterprise: {
      id: { type: String, default: null },
      name: { type: String, default: null },
    },
    user: {
      token: { type: String, default: null },
      scopes: [String],
      id: { type: String, required: true },
      email: { type: String, default: null },
      phone: { type: String, default: null },
    },
    usage: {
      images: { type: Number, default: 0 },
      totalImagesUsed: { type: Number, default: 0 },
      tokens: { type: Number, default: 0 },
      totalTokensUsed: { type: Number, default: 0 },
    },
    plan: {
      type: String,
      default: 'Free Trial',
    },
    subscription: {
      customerId: { type: String, default: null },
      subscriptionId: { type: String, default: null },
      sessionId: { type: String, default: null },
      isActive: { type: Boolean, default: false },
      status: { type: String, default: null },
      quantity: { type: Number, default: 1 },
      paymentInterval: { type: String, default: null },
      lastPaymentDate: { type: Number, default: null },
      validityEndDate: { type: Number, default: null },
    },
    tokenType: {
      type: String,
      default: null,
    },
    isEnterpriseInstall: {
      type: Boolean,
      default: false,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
    isAdminUserSetup: {
      type: Boolean,
      default: false,
    },
    trialExpired: {
      type: Boolean,
      default: false,
    },
    trialEndsOn: {
      type: Number,
      default: null,
    },
    appId: {
      type: String,
      default: null,
    },
    authVersion: {
      type: String,
      default: null,
    },
    bot: {
      scopes: [String],
      token: String,
      userId: String,
      id: String,
    },
  },
  { _id: false, timestamps: true }
);

module.exports.InstallationModel = mongoose.model('SlackInstallation', SlackInstallation);
