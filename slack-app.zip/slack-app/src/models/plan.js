const mongoose = require('mongoose');

const Plans = mongoose.Schema(
  {
    _id: {
      type: mongoose.Schema.Types.ObjectId,
      auto: true,
    },
    name: {
      type: String,
      required: [true, 'Plan name is required'],
    },
    product: {
      type: String,
      required: [true, 'Product name is required'],
    },
    platform: {
      type: String,
      required: [true, 'Platform name is required'],
    },
    description: {
      type: String,
    },
    stripeProductId: {
      type: String,
      index: true,
    },
    stripePlanId: {
      type: String,
      index: true,
    },
    stripePriceId: {
      type: String,
      index: true,
    },
    stripeAnnualPriceId: {
      type: String,
      default: null,
      index: true,
    },
    billingInterval: {
      type: String,
    },
    limits: {
      images: { type: Number },
      tokens: { type: Number },
    },
  },
  { _id: false, timestamps: true, autoCreate: true }
);

module.exports.PlansModel = mongoose.model('Plans', Plans);
