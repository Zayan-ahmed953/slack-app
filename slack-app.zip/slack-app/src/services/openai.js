const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const openai = new OpenAIApi(configuration);


const askCodex = async ({ prompt, choices = 1, userId = '123456', isPaidUser = false }) => {
  const result = await openai.createCompletion({
    model: 'code-davinci-002',
    prompt: prompt,
    n: choices,
    temperature: 0.3,
    max_tokens: 2048,
    best_of: 1,
    top_p: 1,
    frequency_penalty: 0,
    presence_penalty: 0,
    stream: false,
    user: userId,
  });

  return {
    results: result.data.choices.map(post => post.text),
    tokens: result.data.usage.total_tokens,
  };
};

const askGpt3 = async ({ prompt, choices = 1, userId = '123456', isPaidUser = false }) => {
  const result = await openai.createCompletion({
    model: 'text-davinci-003',
    prompt: prompt,
    n: choices,
    temperature: 0.7,
    max_tokens: 2048,
    best_of: 1,
    top_p: 1,
    frequency_penalty: 0,
    presence_penalty: 0,
    stream: false,
    user: userId,
  });

  return {
    results: result.data.choices.map(post => post.text),
    tokens: result.data.usage.total_tokens,
  };
};

const askChatGpt = async ({ chat, userId = '123456', isPaidUser = false }) => {
  const result = await openai.createChatCompletion({
    model: 'gpt-4-turbo',
    n: 1,
    temperature: 0.7,
    max_tokens: 1334,
    frequency_penalty: 0,
    presence_penalty: 0,
    stream: false,
    user: userId,
    messages: chat,
  });

  return {
    results: result.data.choices.map(chat => chat.message.content),
    tokens: result.data.usage.total_tokens,
  };
};

const askDallE = async ({ prompt, choices = 1, userId = '123456', isPaidUser = false }) => {
  const result = await openai.createImage({
    prompt: prompt,
    n: choices,
    size: '512x512',
    user: userId,
  });

  return result.data.data.map(image => image.url);
};

module.exports = {
  askCodex,
  askGpt3,
  askChatGpt,
  askDallE,
};
