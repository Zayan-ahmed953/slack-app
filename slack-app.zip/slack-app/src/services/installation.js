const { InstallationModel } = require('../models/installation');
const { UserModel } = require('../models/user');
const { segmentClient, Bugsnag } = require('../analytics');
const axios = require('axios');

async function setupAllTeamUsers({ token, teamId, teamName }) {
  let cursor = 0;
  let limit = 50;

  do {
    const response = await axios.get('https://slack.com/api/users.list', {
      headers: { Authorization: `Bearer ${token}` },
      params: { cursor, limit, team_id: `${teamId}` },
    });

    cursor = response.data.response_metadata.next_cursor;
    for (const user of response.data.members) {
      if (user.is_bot || user.name === 'slackbot') continue;

      await UserModel.findOneAndUpdate(
        { userId: `${teamId}-${user.id}` },
        {
          userId: `${teamId}-${user.id}`,
          localId: user.id,
          globalId: null,
          name: user.name,
          displayName: user.real_name,
          email: user.profile.email,
          phone: null,
          teamId: teamId,
          team: teamName,
          meta: {
            isFirstMessage: true,
          },
        },
        { upsert: true }
      ).lean();

      segmentClient.identify({
        userId: `${teamId}-${user.id}`,
        traits: {
          userId: `${teamId}-${user.id}`,
          groupId: teamId,
          team: teamName,
          username: user.name,
          name: user.real_name || user.name,
          email: user.profile.email,
        },
      });
    }
  } while (cursor !== '');
}

function getTrialEndTimestamp(trialDays) {
  const secondsInDays = parseInt(trialDays) * 24 * 60 * 60;
  return Math.floor(Date.now() / 1000) + secondsInDays; //+ TRIAL_GRACE_PERIOD
}

const saveInstallation = async installationQuery => {
  console.log('store installation query: ', installationQuery);

  const {
    team: { id: teamId = null, name: teamName = null } = {},
    enterprise: { id: enterpriseId = null, name: enterpriseName = null } = {},
    user: { userToken = null, userScopes = [], id: userId = null } = {},
    bot = null,
    tokenType,
    isEnterpriseInstall,
    appId,
    authVersion,
  } = installationQuery;

  if (teamId === null && enterpriseId === null && userId === null) {
    throw new Error('Invalid installation query');
  }

  let plan = 'Free Trial';
  let usage = { images: 0, tokens: 0 };
  let subscription = {
    customerId: null,
    subscriptionId: null,
    sessionId: null,
    isActive: false,
    status: null,
    quantity: 1,
    paymentInterval: null,
    lastPaymentDate: null,
    validityEndDate: null,
  };

  let trialExpired = false;
  let trialEndsOn = getTrialEndTimestamp((trialDays = 7));

  const previousInstallation = await InstallationModel.find({
    'team.id': teamId,
    'enterprise.id': enterpriseId,
  }).lean();

  if (previousInstallation[0]) {
    plan = previousInstallation[0].plan;
    usage = previousInstallation[0].usage;
    subscription = previousInstallation[0].subscription;
    trialExpired = previousInstallation[0].trialExpired;
    trialEndsOn = previousInstallation[0].trialEndsOn;
  }

  const newInstallation = await InstallationModel.findOneAndUpdate(
    { 'team.id': teamId, 'enterprise.id': enterpriseId },
    {
      team: { id: teamId, name: teamName },
      enterprise: { id: enterpriseId, name: enterpriseName },
      user: { token: userToken, scopes: userScopes, id: userId, email: null },
      usage: usage,
      plan: plan,
      subscription: subscription,
      tokenType: tokenType,
      isEnterpriseInstall: isEnterpriseInstall,
      isDeleted: false,
      isAdminUserSetup: false,
      trialExpired: trialExpired,
      trialEndsOn: trialEndsOn,
      appId: appId,
      authVersion: authVersion,
      bot: bot,
    },
    { upsert: true }
  ).lean();

  await setupAllTeamUsers({
    token: bot.token,
    teamId: teamId,
    teamName: teamName,
  });

  return newInstallation;
};

const findInstallation = async installationQuery => {
  try {
    console.log('find installation query: ', installationQuery);
    const { enterpriseId, teamId } = installationQuery;

    if (teamId === undefined && enterpriseId === undefined) {
      throw new Error('Invalid installation query');
    }

    const installation = await InstallationModel.find({
      isDeleted: false,
      $or: [{ 'team.id': teamId }, { 'enterprise.id': enterpriseId }],
    }).lean();

    if (installation[0] !== undefined) {
      return installation[0];
    } else {
      throw new Error('Error finding installation');
    }
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const deleteInstallation = async installationQuery => {
  try {
    console.log('delete installation query: ', installationQuery);
    const { enterpriseId, teamId } = installationQuery;

    if (teamId === undefined && enterpriseId === undefined) {
      throw new Error('Invalid installation query');
    }

    const installation = await InstallationModel.findOneAndUpdate(
      { 'team.id': teamId, 'enterprise.id': enterpriseId },
      { isDeleted: true },
      { new: true }
    ).lean();

    if (installation !== undefined) {
      return installation;
    } else {
      throw new Error('Error deleting installation');
    }
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

module.exports = {
  saveInstallation,
  findInstallation,
  deleteInstallation,
};
