const axios = require('axios');
const { RateLimiterMemory } = require('rate-limiter-flexible');
const { createClient } = require('redis');

const tok2words = tok => parseInt((tok / 100) * 75);

const wait = waitTime => new Promise(resolve => setTimeout(resolve, waitTime));

const transferImageToS3 = async url => {
  const response = await axios.post(process.env.S3_TRANSFER_LAMBDA, {
    url,
    s3Bucket: process.env.S3_BUCKET,
  });

  return response.data.s3Url;
};

// ================================================================================
//      RATE LIMITERS (have to handle these in a cleaner way later)
// ================================================================================

const paidUserMessageLimit = 60;
const paidUserMessageLimiter = new RateLimiterMemory({
  points: paidUserMessageLimit, // messages
  duration: 60, // Per Minute
});

const freeUserMessageLimit = 20;
const freeUserMessageLimiter = new RateLimiterMemory({
  points: freeUserMessageLimit, // messages
  duration: 60, // Per Minute
});

// const paidUserTokenLimit = 4000;
const paidUserTokenLimit = 13334;
const paidUserTokenLimiter = new RateLimiterMemory({
  points: paidUserTokenLimit, // Tokens
  duration: 60, // Per Minute
});

// const freeUserTokenLimit = 667;
const freeUserTokenLimit = 13334;
const freeUserTokenLimiter = new RateLimiterMemory({
  points: freeUserTokenLimit, // Tokens
  duration: 60, // Per Minute
});

const paidApiTokenLimit = 250000;
const paidApiTokenLimiter = new RateLimiterMemory({
  points: paidApiTokenLimit, // Tokens
  duration: 60, // Per Minute
});

const freeApiTokenLimit = 150000;
const freeApiTokenLimiter = new RateLimiterMemory({
  points: freeApiTokenLimit, // Tokens
  duration: 60, // Per Minute
});

const checkRateLimits = async ({ id, isSubscriptionActive }) => {
  const messageLimiter = isSubscriptionActive ? paidUserMessageLimiter : freeUserMessageLimiter;
  const messageLimit = isSubscriptionActive ? paidUserMessageLimit : freeUserMessageLimit;

  const userTokenLimiter = isSubscriptionActive ? paidUserTokenLimiter : freeUserTokenLimiter;
  const userTokenLimit = isSubscriptionActive ? paidUserTokenLimit : freeUserTokenLimit;

  const apiTokenLimiter = isSubscriptionActive ? paidApiTokenLimiter : freeApiTokenLimiter;
  const apiTokenLimit = isSubscriptionActive ? paidApiTokenLimit : freeApiTokenLimit;

  // check user message usage per minute
  const userMessageLimitInstance = await messageLimiter.get(id);
  if (userMessageLimitInstance !== null) {
    if (userMessageLimitInstance.remainingPoints <= 0) {
      return (
        `Your usage has exceeded the fair usage policy of ` +
        `${messageLimit} requests per minute. ` +
        `Please wait ${Math.floor(
          userMessageLimitInstance.msBeforeNext / 1000
        )} seconds before sending the next message.`
      );
    }
  }

  // check user token usage per minute
  const userTokenLimitInstance = await userTokenLimiter.get(id);
  if (userTokenLimitInstance !== null) {
    if (userTokenLimitInstance.remainingPoints <= 0) {
      return (
        `Your usage has exceeded the fair usage policy of ` +
        `${tok2words(userTokenLimit)} words per minute. ` +
        `Please wait ${Math.floor(userTokenLimitInstance.msBeforeNext / 1000)} seconds before sending the next message.`
      );
    }
  }

  // check overall Slack app usage per minute
  const apiTokenLimitInstance = await apiTokenLimiter.get('SLACK');
  if (apiTokenLimitInstance !== null) {
    if (apiTokenLimitInstance.remainingPoints <= 0) {
      let message = 'Due to high demand, the system is currently overloaded. Please try again in a few minutes.';
      if (!isSubscriptionActive) {
        message +=
          '\n\nTo ensure uninterrupted and quick access, please update your subscription plan through the app home.' +
          '\n\nIf you require any assistance, please contact us at hello@hexane.ai';
      }
      return message;
    }
  }
};

const consumeRateLimit = async ({ id, isSubscriptionActive, tokens }) => {
  const messageLimiter = isSubscriptionActive ? paidUserMessageLimiter : freeUserMessageLimiter;
  const userTokenLimiter = isSubscriptionActive ? paidUserTokenLimiter : freeUserTokenLimiter;
  const apiTokenLimiter = isSubscriptionActive ? paidApiTokenLimiter : freeApiTokenLimiter;

  await messageLimiter.consume(id, 1);
  await userTokenLimiter.consume(id, tokens);
  await apiTokenLimiter.consume('SLACK', tokens);
};

// ================================================================================

// ================================================================================
//      CONTEXT RESET & TRACKING (have to handle these in a cleaner way later)
// ================================================================================

let redisClient;
const initContextCache = async () => {
  if (!redisClient) {
    redisClient = createClient();

    redisClient.on('connect', () => {
      console.log('Redis Store: connected');
    });
    redisClient.on('end', () => {
      console.log('Redis Store: disconnected');
    });
    redisClient.on('reconnecting', () => {
      console.log('Redis Store: reconnecting');
    });
    redisClient.on('error', err => {
      console.log('Redis Store: error ', { err });
    });

    await redisClient.connect();
  }
};

const contextTokenLimit = 3350;
const contextExpiration = 60 * 30; // Thirty Minutes
const contextTokenLimiter = new RateLimiterMemory({
  points: contextTokenLimit,
  duration: contextExpiration,
});

const getChatContext = async ({ id }) => {
  const contextTokenLimiterInstance = await contextTokenLimiter.get(id);
  if (contextTokenLimiterInstance !== null) {
    if (contextTokenLimiterInstance.remainingPoints <= 0) {
      contextTokenLimiter.delete(id);
      await redisClient.del(id);
    }

    // return context if exists
    const context = await redisClient.get(id);
    if (context) return JSON.parse(context);
  }
  return;
};

const setChatContext = async ({ id, context, tokens }) => {
  await redisClient.setEx(id, contextExpiration, JSON.stringify(context));

  try {
    await contextTokenLimiter.consume(id, tokens);
  } catch (error) {
    if (error.consumedPoints) {
      contextTokenLimiter.delete(id);
      await redisClient.del(id);
    }
  }
};

const resetChatContext = async ({ id }) => {
  contextTokenLimiter.delete(id);
  await redisClient.del(id);
};

const getResponseFromRedis = async (messageId) => {
  const response = await redisClient.get(messageId);
  const responseString = response;
  return responseString;
};

const setResponseInRedis = async (messageId, response) => {
  await redisClient.set(messageId, response, { EX: 7200 });
};

const deleteResponseFromRedis = async (messageId) => {
  const exists = await redisClient.exists(messageId);
  if (exists) {   
    await redisClient.del(messageId);
  }
};

const enhancePrompt = (prompt) => {  
  return `Please provide a well-structured, detailed, and accurate response while maintaining clarity and relevance. Ensure completeness and coherence in the response. Here is the user request: ${prompt}`;
}

// ================================================================================

module.exports = {
  transferImageToS3,
  tok2words,
  wait,
  checkRateLimits,
  consumeRateLimit,
  initContextCache,
  getChatContext,
  setChatContext,
  resetChatContext,
  getResponseFromRedis,
  setResponseInRedis,
  enhancePrompt,
  deleteResponseFromRedis,
};
