const { askChatGpt } = require('../services/openai');
const { updateTokensUsage } = require('../services/subscription');
const { getDirectMessageBlock, getRateLimitBlock } = require('../interfaces');
const { checkRateLimits, consumeRateLimit, getChatContext, setChatContext, resetChatContext } = require('../utilities');
const { preDefinedResponses } = require('./constants');
const { segmentClient, Bugsnag } = require('../analytics');

const directMessageCb = async ({ context, event, say }) => {
  try {
    const prompt = context.matches[0].replace('\n', ' ');
    let response = '';

    if (typeof preDefinedResponses[prompt.toLowerCase()] !== 'undefined') {
      response = preDefinedResponses[prompt.toLowerCase()];
      await say({
        blocks: getDirectMessageBlock(response),
        text: response,
      });
      return;
    }

    const rateLimiterMessage = await checkRateLimits({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
    });

    if (rateLimiterMessage) {
      await say({
        blocks: getRateLimitBlock(rateLimiterMessage),
        text: rateLimiterMessage,
      });
      return;
    }

    let chat = [];
    const chatContext = await getChatContext({ id: `${context.teamId}-${event.user}` });
    if (chatContext && chatContext !== []) {
      chatContext.push({ role: 'user', content: `${prompt}` });
      chat = chatContext;
    } else {
      // await say({
      //   blocks: getDirectMessageBlock('*Note: The context of this conversation has been reset ♻️*'),
      //   text: 'Note: The context of this conversation has been reset.',
      // });

      chat = [
        {
          role: 'system',
          content:
            'You are a helpful AI assistant trained by Hexane Ai. Your name is Ai Intern. ' +
            'Your job is to be of assistance to the user in any way possible.',
        },
        { role: 'assistant', content: 'Hi, how can I help you?' },
        { role: 'user', content: `${prompt}` },
      ];
    }

    const { results, tokens } = await askChatGpt({
      chat: chat,
      userId: event.user,
      isPaidUser: context.installation.subscription.isActive,
    });

    response = results[0].replace('I am a language model trained by OpenAI', 'I am a language model trained by Hexane');
    await say({
      blocks: getDirectMessageBlock(response),
      text: response,
    });

    chat.push({ role: 'assistant', content: `${results[0]}` });
    await setChatContext({ id: `${context.teamId}-${event.user}`, context: chat, tokens: tokens });
    await updateTokensUsage({ installation: context.installation, newTokensUsed: tokens });
    await consumeRateLimit({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
      tokens,
    });

    segmentClient.track({
      userId: `${context.teamId}-${event.user}`,
      event: 'Message',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${event.user}`,
        prompt: prompt,
        tokens: tokens,
      },
    });
  } catch (error) {
    await resetChatContext({ id: `${context.teamId}-${event.user}` });
    if (error.consumedPoints) {
      // ignore this error. it's a rate limiter error.
      // rate limitation messages are handled with the features that are rate limited
      return;
    }

    // Bugsnag.notify(error);
    console.error(error);
  }
};

module.exports.register = app => {
  app.message(/^().*/, directMessageCb);
};
