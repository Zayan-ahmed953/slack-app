const { askChatGpt, askDallE } = require('../services/openai');
const { transferImageToS3, checkRateLimits, consumeRateLimit, setResponseInRedis, enhancePrompt } = require('../utilities');
const { preDefinedResponses } = require('./constants');
const { segmentClient, Bugsnag } = require('../analytics');

const {
  updateTokensUsage,
  updateImagesUsage,
  getStripePaymentUrl,
  getStripePortalUrl,
} = require('../services/subscription');

const {
  getTextBlockDraft,
  getImgBlockDraft,
  getRateLimitBlock,
  getManageBlock,
  getQuickGuide,
} = require('../interfaces');

const { v4: uuidv4 } = require('uuid');

const textCommandCb = async ({ ack, respond, payload, context, client }) => {
  await ack();
  const messageId = uuidv4();
  const prompt = payload.text;
  let response = '';

  let loadingMessageTs = null
  try {
    const loadingMessage = await client.chat.postMessage({
      channel: payload.channel_id,
      text: "Processing your request...⌛",
    });
    loadingMessageTs = loadingMessage.ts;
  } catch (error) {
    console.log("Error:", error.data.error);
  }

  try {
    if (typeof preDefinedResponses[prompt.toLowerCase()] !== 'undefined') {
      if (loadingMessageTs) {
        await client.chat.delete({
          channel: payload.channel_id,  
          ts: loadingMessageTs,
        });
      }
      response = preDefinedResponses[prompt.toLowerCase()];
      setResponseInRedis(messageId, response)
      await respond({
        blocks: getTextBlockDraft(prompt, response, messageId),
        text: response,
      });
      return;
    }

    if (prompt.toLowerCase().trim() === 'help') {
      await respond({
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: "\n*Ask Intern with `/intern` command*:  \n\nLeverage the limitless power of AI in your Slack Channels and Chats. \n\n*Example*: ```/intern brainstorm 5 ideas for promoting AI Intern's new AI powered Slack bot```\n\n",
            },
          },
        ],
        text: 'Ask Intern with /intern command',
      });
      return;
    }

    const rateLimiterMessage = await checkRateLimits({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
    });

    if (rateLimiterMessage) {
      await respond({
        blocks: getRateLimitBlock(rateLimiterMessage),
        text: rateLimiterMessage,
      });
      return;
    }

    const enhancedPrompt = enhancePrompt(prompt);
    const { results, tokens } = await askChatGpt({
      chat: [
        {
          role: 'system',
          content:
            'You are a highly skilled AI writing assistant named Ai Intern. ' +
            'Your primary role is to help users generate high-quality, well-structured content. ' +
            'Ensure the response is clear, engaging',
        },
        { role: 'assistant', content: 'Hi, how can I help you?' },
        { role: 'user', content: `${enhancedPrompt}` },
      ],
      userId: payload.user_id,
      isPaidUser: context.installation.subscription.isActive,
    });
    response = results[0].replace('I am a language model trained by OpenAI', 'I am a language model trained by Hexane');

    await updateTokensUsage({ installation: context.installation, newTokensUsed: tokens });
    await consumeRateLimit({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
      tokens,
    });

    segmentClient.track({
      userId: `${context.teamId}-${payload.user_id}`,
      event: 'Intern',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${payload.user_id}`,
        prompt: prompt,
        tokens: tokens,
      },
    });


    setResponseInRedis(messageId, response)
    if (loadingMessageTs) {
      await client.chat.delete({
        channel: payload.channel_id,  
        ts: loadingMessageTs,
      });
    }

    await respond({
      blocks: getTextBlockDraft(prompt, response, messageId),
      text: response,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error("Error:",error.response);
  }
};

const imageCommandCb = async ({ ack, respond, payload, context }) => {
  await ack();

  try {
    if (payload.text.toLowerCase().trim() === 'help') {
      await respond({
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: '\n*Use `/image` to generate Ai images*:  \n\nCreate realistic images and art from a description in natural language. \n\n*Example*: ```/image A photo of a teddy bear on a skateboard in Times Square```\n\n',
            },
          },
        ],
        text: 'Use /image to generate Ai images',
      });
      return;
    }

    const openAiImages = await askDallE({
      prompt: payload.text,
      userId: payload.user_id,
      isPaidUser: context.installation.subscription.isActive,
    });
    await updateImagesUsage({ installation: context.installation, newImagesUsed: 1 });
    const imageS3Url = await transferImageToS3(openAiImages[0]);

    segmentClient.track({
      userId: `${context.teamId}-${payload.user_id}`,
      event: 'Image',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${payload.user_id}`,
        prompt: payload.text,
        tokens: 0,
      },
    });

    await respond({
      response_type: 'ephemeral',
      blocks: getImgBlockDraft(payload.text, imageS3Url),
      text: imageS3Url,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const codeCommandCb = async ({ ack, respond, payload, context }) => {
  await ack();

  try {
    const prompt = payload.text;
    let response = '';

    if (typeof preDefinedResponses[prompt.toLowerCase()] !== 'undefined') {
      response = preDefinedResponses[prompt.toLowerCase()];
      await respond({
        blocks: getTextBlockDraft(prompt, response),
        text: response,
      });
      return;
    }

    if (payload.text.toLowerCase().trim() === 'help') {
      await respond({
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: '\n*Get code snippets using `/code`*: \n\nTranslates natural language to code. \n\n*Example*: ```/code a javascript function for generating the Fibonacci sequence```\n\n',
            },
          },
        ],
        text: 'Get code snippets using /code',
      });
      return;
    }

    const rateLimiterMessage = await checkRateLimits({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
    });

    if (rateLimiterMessage) {
      await respond({
        blocks: getRateLimitBlock(rateLimiterMessage),
        text: rateLimiterMessage,
      });
      return;
    }

    const { results, tokens } = await askChatGpt({
      chat: [
        {
          role: 'system',
          content:
            'You are a helpful AI programmer named Ai Intern. ' +
            "Your job is to provide snippets of code to the user about any programming or code related task he asks about. You don't need to explain much.",
        },
        { role: 'assistant', content: 'Hi, how can I help you?' },
        { role: 'user', content: `${prompt}` },
      ],
      userId: payload.user_id,
      isPaidUser: context.installation.subscription.isActive,
    });
    response = results[0].replace('I am a language model trained by OpenAI', 'I am a language model trained by Hexane');

    await updateTokensUsage({ installation: context.installation, newTokensUsed: tokens });
    await consumeRateLimit({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
      tokens,
    });

    segmentClient.track({
      userId: `${context.teamId}-${payload.user_id}`,
      event: 'Code',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${payload.user_id}`,
        prompt: prompt,
        tokens: tokens,
      },
    });

    await respond({
      blocks: getTextBlockDraft(prompt, response, true),
      text: response,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const manageCommandCb = async ({ ack, respond, payload, context }) => {
  await ack();
  try {
    segmentClient.track({
      userId: `${context.teamId}-${payload.user_id}`,
      event: 'Manage',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${payload.user_id}`,
      },
    });

    const stripePortalUrl = await getStripePortalUrl({ installation: context.installation });
    const stripeCheckOutUrls = {
      individualsPlan: await getStripePaymentUrl({ installation: context.installation, planName: 'Individuals' }),
      workspacePlan: await getStripePaymentUrl({ installation: context.installation, planName: 'Workspace' }),
    };

    await respond({
      blocks: getManageBlock({
        plan: context.planDetails,
        installation: context.installation,
        stripePortalUrl: stripePortalUrl,
        stripeCheckOutUrls: stripeCheckOutUrls,
      }),
      text: 'Ai Intern Manage Portal',
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const helpCommandCb = async ({ ack, respond, payload, context }) => {
  await ack();
  try {
    segmentClient.track({
      userId: `${context.teamId}-${payload.user_id}`,
      event: 'Help',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${payload.user_id}`,
      },
    });

    await respond({
      blocks: getQuickGuide(),
      text: 'Ai Intern Quick Guide',
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

module.exports.register = app => {
  app.command('/intern', textCommandCb);
  app.command('/image', imageCommandCb);
  app.command('/code', codeCommandCb);
  app.command('/intern-manage', manageCommandCb);
  app.command('/intern-help', helpCommandCb);
};
