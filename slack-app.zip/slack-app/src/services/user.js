const { UserModel } = require('../models/user');

const getCurrentUser = async userId => {
  return await UserModel.findOne({
    userId: userId,
  }).lean();
};

const updateFirstMessageCheck = async userId => {
  return await UserModel.findOneAndUpdate({ userId: userId }, { 'meta.isFirstMessage': false }, { new: true }).lean();
};

module.exports = {
  getCurrentUser,
  updateFirstMessageCheck,
};
