const Bugsnag = require('@bugsnag/js');
const Analytics = require('analytics-node');

const segmentClient = new Analytics(process.env.SEGMENT_WRITE_KEY);

// Bugsnag.start({ apiKey: process.env.BUGSNAG_KEY });

module.exports = {
  segmentClient,
  // Bugsnag,
};
