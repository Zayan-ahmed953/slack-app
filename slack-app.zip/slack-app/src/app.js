const { App, LogLevel, ExpressReceiver } = require('@slack/bolt');
const mongoose = require('mongoose');
require('dotenv').config();

const manifest = require('./manifest.json');
const { registerListeners } = require('./listeners');
const { initContextCache } = require('./utilities');
const InstallationService = require('./services/installation');
const { Bugsnag } = require('./analytics');

const {
  attachInstallationDetails,
  attachUserDetails,
  attachPlanDetails,
  validateUserSubscription,
} = require('./middleware');

// ================================================================================

const BoltApp = new App({
  clientId: process.env.SLACK_CLIENT_ID,
  clientSecret: process.env.SLACK_CLIENT_SECRET,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  scopes: manifest.oauth_config.scopes.bot,
  // token: process.env.SLACK_BOT_TOKEN,
  appToken: process.env.SLACK_APP_TOKEN,
  logLevel: LogLevel.INFO,
  // stateSecret: process.env.STATE_SECRET, // ---->> disabled for org wide installation
  installerOptions: {
    stateVerification: false, // ---->> disabled for org wide installation
    directInstall: true,
  },
  installationStore: {
    storeInstallation: InstallationService.saveInstallation,
    fetchInstallation: InstallationService.findInstallation,
    deleteInstallation: InstallationService.deleteInstallation,
  },
});

// ================================================================================

// Use Middleware for Bolt App
BoltApp.use(attachInstallationDetails);
BoltApp.use(attachUserDetails);
BoltApp.use(attachPlanDetails);
BoltApp.use(validateUserSubscription);

// ================================================================================

/**
 * Register Slack Listeners here
 * i.e. Commands, Actions, Events, Messages, Views
 **/
registerListeners(BoltApp);

// ================================================================================

const connectDB = async () => {
  const connection = await mongoose.connect(process.env.MONGODB_URI || '', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  return connection.connection.db;
};

const db = connectDB()
  .then(() => console.log('Database connected successfully\n'))
  .catch(error => {
    // Bugsnag.notify(error);
    throw new Error('\nError connecting to mongodb');
  });

initContextCache()
  .then(() => console.log('Redis store initialized\n'))
  .catch(error => {
    handleError(error);
  });  

(async () => {
  await BoltApp.start(process.env.PORT || 3000);
  console.log('\n⚡️ Bolt app is running!\n');
})();
