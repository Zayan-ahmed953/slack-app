const MAX_CHARACTERS = 3000;
const MAX_BLOCKS = 50;

  function splitTextIntoBlocks(text, maxCharacters){
    let chunks = [];
    let paragraphs = text.split("\n\n");
    let currentChunk = "";
  
    for (let paragraph of paragraphs) {
      if ((currentChunk + paragraph).length > maxCharacters) {
        chunks.push(currentChunk.trim());
        currentChunk = paragraph;
      } else {
        currentChunk += (currentChunk ? "\n\n" : "") + paragraph;
      }
    }
    if (currentChunk) chunks.push(currentChunk.trim());
    return chunks;
  }

function getTextBlockDraft(prompt, response, messageId, isCode = false) {
  let blocks = [];
  response = response.replace(/\*\*/g, '*');
  console.log("getTextBlockDraft Message ID:", messageId);
  blocks.push({
    type: "section",
    text: {
      type: "mrkdwn",
      text: `*${prompt}*`
    }
  },{
    "type": "divider"
  });
  
  let responseChunks = splitTextIntoBlocks(response, MAX_CHARACTERS);
  responseChunks.slice(0, MAX_BLOCKS - 2).forEach(chunk => {
    blocks.push({
      type: "section",
      text: {
        type: "mrkdwn",
        text: chunk,
      },
    });
  });

  blocks.push({
    type: 'actions',
    elements: [
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Send',
        },
        style: 'primary',
        value: messageId,
        action_id: isCode ? 'button_code_send' : 'button_text_send',
      },
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Regenerate',
        },
        value: JSON.stringify({ prompt, messageId }),
        action_id: isCode ? 'button_code_regenerate' : 'button_text_regenerate',
      },
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Cancel',
        },
        value: messageId,
        action_id: 'button_cancel',
      },
    ],
  });
  return blocks;
}

const getTextBlockFinal = (text, userId, isCode = false) => {
  text = text.replace(/\*\*/g, '*');
  let responseChunks = splitTextIntoBlocks(text, MAX_CHARACTERS);
  const blocks = [];
  responseChunks.forEach(chunk => {
    blocks.push({
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: isCode ? '```' + `${chunk}` + '\n```' : `${chunk}`,
    },
    });
  });
  blocks.push({
    type: 'context',
    elements: [
      // {
      //   type: 'image',
      //   image_url: 'https://',
      //   alt_text: 'Ai Intern logo'
      // },
      {
        type: 'mrkdwn',
        text: `Posted by <@${userId}> via AI Intern | Scale with AI`,
      },
    ],
  });
  return blocks;
}

const getImgBlockDraft = (prompt, imageUrl) => [
  {
    type: 'section',
    text: {
      type: 'mrkdwn',
      text: prompt,
    },
  },
  {
    type: 'divider',
  },
  {
    type: 'image',
    image_url: imageUrl,
    alt_text: 'marg',
  },
  {
    type: 'actions',
    elements: [
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Send',
        },
        style: 'primary',
        value: imageUrl,
        action_id: 'button_image_send',
      },
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Regenerate',
        },
        value: prompt,
        action_id: 'button_image_regenerate',
      },
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Cancel',
        },
        action_id: 'button_cancel',
      },
    ],
  },
];

const getImgBlockFinal = (imageUrl, userId) => [
  {
    type: 'image',
    // title: {
    //   type: 'plain_text',
    //   "text": prompt,
    //   emoji: true,
    // },
    image_url: imageUrl,
    alt_text: 'marg',
  },
  {
    type: 'context',
    elements: [
      // {
      //   type: 'image',
      //   image_url: 'https://',
      //   alt_text: 'AI Intern logo'
      // },
      {
        type: 'mrkdwn',
        text: `Posted by <@${userId}> via AI Intern | Scale with AI`,
        verbatim: false,
      },
    ],
  },
];

const getDirectMessageBlock = text => [
  {
    type: 'section',
    text: {
      type: 'mrkdwn',
      text: `${text}`,
    },
  },
];

const getRedirectMessageBlock = ({ text, button, redirectUrl }) => {
  return {
    type: 'section',
    text: {
      type: 'mrkdwn',
      text: `${text}`,
    },
    accessory: {
      type: 'button',
      text: {
        type: 'plain_text',
        text: `${button}`,
      },
      url: redirectUrl,
      style: 'primary',
      value: 'ignore_action',
      action_id: 'ignore_action',
    },
  };
};

const getRateLimitBlock = message => [
  {
    type: 'section',
    text: {
      type: 'mrkdwn',
      text: `${message}`,
    },
  },
  {
    type: 'actions',
    elements: [
      {
        type: 'button',
        text: {
          type: 'plain_text',
          text: 'Ok',
        },
        action_id: 'button_cancel',
      },
    ],
  },
];

const getManageBlock = ({ plan, installation, stripePortalUrl, stripeCheckOutUrls }) => {
  const validityEndDate =
    plan.name === 'Free Trial' ? installation.trialEndsOn : installation.subscription.validityEndDate;

  const manageBlock = [
    {
      type: 'header',
      text: {
        type: 'plain_text',
        text: `Current Plan: ${plan.name}`,
        emoji: true,
      },
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `<!date^${validityEndDate}^Valid Till: {date_long}|[refreshing date...]>`,
      },
    },
    { type: 'divider' },
  ];

  // push subscription buttons to manageBlock
  if (plan.name === 'Free Trial' || !installation.subscription.isActive) {
    const individualsPlanCheckoutBlock = getRedirectMessageBlock({
      text: 'Get 500,000 Words & 150 Images for 12$/month: ',
      button: 'Activate Individuals Plan',
      redirectUrl: stripeCheckOutUrls.individualsPlan,
    });

    const workspacePlanCheckoutBlock = getRedirectMessageBlock({
      text: 'Get UNLIMITED Words & 300 Images for 25$/month: ',
      button: 'Activate Workspace Plan',
      redirectUrl: stripeCheckOutUrls.workspacePlan,
    });

    manageBlock.push(
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text:
            `To use Ai Intern without any interruptions, activate the premium plan of your choice. ` +
            `Learn more about Ai Intern subscription plans at: ${process.env.SLACK_APP_LANDING_PAGE}\n\n`,
        },
      },
      { type: 'divider' },
      workspacePlanCheckoutBlock,
      individualsPlanCheckoutBlock
    );
  } else {
    if (plan.name === 'Individuals') {
      const workspacePlanCheckoutBlock = getRedirectMessageBlock({
        text: 'Upgrade to Ai Intern Workspace Plan: ',
        button: 'Upgrade Subscription',
        redirectUrl: stripeCheckOutUrls.workspacePlan,
      });

      manageBlock.push(
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text:
              `Upgrade to the Workspace Plan to get UNLIMITED ACCESS to Ai Intern. ` +
              `Learn more about Ai Intern subscription plans at: ${process.env.SLACK_APP_LANDING_PAGE}`,
          },
        },
        { type: 'divider' },
        workspacePlanCheckoutBlock
      );
    }

    if (installation.subscription.isActive) {
      const stripePortalBlock = getRedirectMessageBlock({
        text: 'Manage your Ai Intern subscription: ',
        button: 'Manage Subscription',
        redirectUrl: stripePortalUrl,
      });
      manageBlock.push(stripePortalBlock);
    }
  }

  // push usage block elements to manageBlock
  const tok2words = tok => parseInt((tok / 100) * 75);
  const usedWords = tok2words(installation.usage.tokens);
  const remainingWords = Math.max(tok2words(plan.limits.tokens) - tok2words(installation.usage.tokens), 0);
  const remainingImages = plan.limits.images - installation.usage.images;

  const usageBlock = [
    {
      type: 'header',
      text: {
        type: 'plain_text',
        text: 'Usage:',
        emoji: true,
      },
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `*Text*:\n>Used: ${usedWords} words\n>Remaining: ${remainingWords} words`,
      },
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `*Images*:\n>Used: ${installation.usage.images} images\n>Remaining: ${remainingImages} images`,
      },
    },
    { type: 'divider' },
    {
      type: 'header',
      text: {
        type: 'plain_text',
        text: 'Contact Us:',
        emoji: true,
      },
    },
    getRedirectMessageBlock({
      text: 'If you require any assistance, \nfeel free to contact us at: hello@aiintern.io',
      button: 'Contact Support',
      redirectUrl: 'mailto:hello@aiintern.io',
    }),
  ];

  manageBlock.push({ type: 'divider' }, ...usageBlock);

  return manageBlock;
};

const getQuickGuide = () => {
  return [
    {
      type: 'header',
      text: {
        type: 'plain_text',
        text: 'Quick Guide:',
        emoji: true,
      },
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: '\n*Direct Messages*:  \n\nFind Ai Intern in your slack apps and just send a message explaining anything you want Ai Intern to help you with.\n\n',
      },
    },
    { type: 'divider' },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: "\n*Ask Intern with `/intern` command*:  \n\nLeverage the limitless power of AI in your Slack Channels and Chats. \n\n*Example*: ```/intern brainstorm 5 ideas for promoting AI Intern's new AI powered Slack bot```\n\n",
      },
    },
    {
      type: 'divider',
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: '\n*Use `/image` to generate Ai images*:  \n\nCreate realistic images and art from a description in natural language. \n\n*Example*: ```/image A photo of a teddy bear on a skateboard in Times Square```\n\n',
      },
    },
    {
      type: 'divider',
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: '\n*Get code snippets using `/code`*: \n\nTranslates natural language to code. \n\n*Example*: ```/code a javascript function for generating the Fibonacci sequence```\n\n',
      },
    },
    {
      type: 'divider',
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: '\n*Manage Ai Intern with `/intern-manage`*:  \n\nManage your Ai Intern subscription & check usage. \n\n',
      },
    },
    {
      type: 'divider',
    },
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: '\n*Send `/intern-help` to get the quick user guide*:  \n\nGet the quick guide on all the Ai Intern features. \n\n',
      },
    },
    { type: 'divider' },
    {
      type: 'header',
      text: {
        type: 'plain_text',
        text: 'Contact Us:',
        emoji: true,
      },
    },
    getRedirectMessageBlock({
      text: 'If you require any assistance, \nfeel free to contact us at: hello@aiintern.io',
      button: 'Contact Support',
      redirectUrl: 'mailto:hello@aiintern.io',
    }),
  ];
};

module.exports = {
  getTextBlockDraft,
  getTextBlockFinal,
  getImgBlockDraft,
  getImgBlockFinal,
  getDirectMessageBlock,
  getRateLimitBlock,
  getManageBlock,
  getQuickGuide,
};
