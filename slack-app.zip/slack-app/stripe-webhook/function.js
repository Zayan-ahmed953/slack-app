const mongoose = require('mongoose');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Bugsnag = require('@bugsnag/js');

const { InstallationModel } = require('./models/installation');
const { PlansModel } = require('./models/plan');

// Bugsnag.start({ apiKey: process.env.BUGSNAG_KEY });

const connectDB = async () => {
  const connection = await mongoose.connect(process.env.MONGODB_URI || '', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  return connection.connection.db;
};

const db = connectDB()
  .then(() => console.log('Database connected successfully\n'))
  .catch(error => {
    console.error('\nError connecting to mongodb', error);
  });

const getPlanDetails = async ({ planName, priceId, priceInterval }) => {
  if (planName) {
    const planDetails = await PlansModel.find({
      name: planName,
      platform: 'Slack',
    }).lean();

    if (planDetails[0] !== undefined) {
      return planDetails[0];
    }
  }

  if (priceId) {
    let planDetails;

    if (priceInterval === 'year') {
      planDetails = await PlansModel.find({
        stripeAnnualPriceId: priceId,
        platform: 'Slack',
      }).lean();
    } else {
      planDetails = await PlansModel.find({
        stripePriceId: priceId,
        platform: 'Slack',
      }).lean();
    }

    if (planDetails[0] !== undefined) {
      return planDetails[0];
    }
  }
};

// =================================================
//     STRIPE EVENT HANDLER FUNCTION
// =================================================

const handleStripeEvent = async ({ event }) => {
  let customer;
  let subscription;
  let currentInstallation;

  console.log({ data: event.data.object });

  switch (event.type) {
    case 'customer.created':
    case 'customer.updated':
      customer = event.data.object;
      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': customer.id },
        {
          'user.email': customer.email,
          'user.phone': customer?.phone ? customer.phone : null,
        },
        { new: true }
      ).lean();
      break;

    case 'customer.deleted':
      customer = event.data.object;
      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': customer.id },
        {
          isDeleted: true,
          'subscription.isActive': false,
        },
        { new: true }
      ).lean();
      break;

    case 'customer.subscription.created':
      subscription = event.data.object;
      currentInstallation = await InstallationModel.findOne({
        'subscription.customerId': subscription.customer,
      }).lean();

      const newPlan = await getPlanDetails({
        priceId: subscription.items.data[0].price.id,
        priceInterval: subscription.items.data[0].price.recurring.interval,
      });

      if (newPlan.name !== currentInstallation.plan) {
        stripe.subscriptions.del(currentInstallation.subscription.subscriptionId);
      }

      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': subscription.customer },
        {
          'subscription.subscriptionId': subscription.id,
          'subscription.quantity': subscription.quantity,
        },
        { new: true }
      ).lean();
      break;

    case 'customer.subscription.deleted':
    case 'customer.subscription.cancelled':
    case 'customer.subscription.pending_update_expired':
      subscription = event.data.object;
      currentInstallation = await InstallationModel.findOne({
        'subscription.customerId': subscription.customer,
      }).lean();

      // ignore if the cancelled subscription isn't the current subscription
      if (currentInstallation.subscription.subscriptionId !== subscription.id) {
        break;
      }

      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': subscription.customer },
        { 'subscription.isActive': false, trialExpired: true },
        { new: true }
      ).lean();
      break;

    case 'customer.subscription.updated':
    case 'customer.subscription.pending_update_applied':
      subscription = event.data.object;
      currentInstallation = await InstallationModel.findOne({
        'subscription.customerId': subscription.customer,
      }).lean();

      if (subscription.status === 'active') {
        const newPlan = await getPlanDetails({
          priceId: subscription.items.data[0].price.id,
          priceInterval: subscription.items.data[0].price.recurring.interval,
        });

        const subscriptionUpdates = {
          trialExpired: true,
          'subscription.isActive': true,
          'subscription.subscriptionId': subscription.id,
          'subscription.quantity': subscription.quantity,
          plan: newPlan.name,
          'subscription.lastPaymentDate': subscription.current_period_start,
          'subscription.validityEndDate': subscription.current_period_end,
          'subscription.paymentInterval': subscription.plan.interval,
        };

        if (!subscription.cancel_at_period_end) {
          if (currentInstallation.subscription.validityEndDate < subscription.current_period_end) {
            subscriptionUpdates['usage.images'] = 0;
            subscriptionUpdates['usage.tokens'] = 0;
          }
        }

        await InstallationModel.findOneAndUpdate(
          { 'subscription.customerId': subscription.customer },
          subscriptionUpdates,
          { new: true }
        ).lean();
      }

      if (subscription.status === 'canceled' || subscription.status === 'unpaid') {
        // ignore if the cancelled subscription isn't the current subscription
        if (currentInstallation.subscription.subscriptionId !== subscription.id) {
          break;
        }

        await InstallationModel.findOneAndUpdate(
          { 'subscription.customerId': subscription.customer },
          { 'subscription.isActive': false, trialExpired: true },
          { new: true }
        ).lean();
      }

      break;

    // ... handle other event types
    default:
      // Bugsnag.notify(new Error(`Unhandled event type ${event.type}`));
      console.log(`Unhandled event type ${event.type}`);
  }
};

// =================================================
//     LAMBDA HANDLER STARTS HERE
// =================================================

module.exports.handler = async event => {
  console.log({ httpMethod: event.httpMethod });

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Headers':
          'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,Stripe-Signature',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST',
      },
    };
  }

  try {
    const sig = event.headers['Stripe-Signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    let stripeEvent;

    stripeEvent = stripe.webhooks.constructEvent(event.body, sig, webhookSecret);
    console.log({ stripeEvent });
    await handleStripeEvent({ event: stripeEvent });

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Headers':
          'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,Stripe-Signature',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST',
      },
    };
  } catch (err) {
    // Bugsnag.notify(err);
    console.error(`Webhook Error: ${err.message}`, err);
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Headers':
          'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,Stripe-Signature',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST',
      },
      body: `Webhook Error: ${err.message}`,
    };
  }
};
