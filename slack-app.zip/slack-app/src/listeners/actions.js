const { askChatGpt, askDallE, askCodex } = require('../services/openai');
const { transferImageToS3, checkRateLimits, consumeRateLimit, setResponseInRedis, getResponseFromRedis, enhancePrompt, deleteResponseFromRedis } = require('../utilities');
const { updateTokensUsage, updateImagesUsage } = require('../services/subscription');
const { preDefinedResponses } = require('./constants');
const { segmentClient, Bugsnag } = require('../analytics');
const {
  getTextBlockDraft,
  getTextBlockFinal,
  getImgBlockDraft,
  getImgBlockFinal,
  getRateLimitBlock,
} = require('../interfaces');

const textSendButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const messageId = body.actions[0].value;
    const openAiResponse = await getResponseFromRedis(messageId)
    // segmentClient.track({
    //   userId: `${context.teamId}-${body.user.id}`,
    //   event: 'Intern',
    //   properties: {
    //     groupId: context.teamId,
    //     userId: `${context.teamId}-${body.user.id}`,
    //   },
    // });

    await respond({
      response_type: 'in_channel',
      delete_original: true,
      blocks: getTextBlockFinal(openAiResponse, body.user.id),
      text: openAiResponse,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const textRegenerateButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const action = JSON.parse(body.actions[0].value);
    const prompt = action.prompt;
    const messageId =  action.messageId;
    let response = '';

    if (typeof preDefinedResponses[prompt.toLowerCase()] !== 'undefined') {
      response = preDefinedResponses[prompt.toLowerCase()];
      setResponseInRedis(messageId, response)
      await respond({
        replace_original: true,
        blocks: getTextBlockDraft(prompt, response , messageId),
        text: response,
      });
      return;
    }

    const rateLimiterMessage = await checkRateLimits({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
    });

    if (rateLimiterMessage) {
      await respond({
        replace_original: true,
        blocks: getRateLimitBlock(rateLimiterMessage),
        text: rateLimiterMessage,
      });
      return;
    }

    const enhancedPrompt = enhancePrompt(prompt);
    const { results, tokens } = await askChatGpt({
      chat: [
        {
          role: 'system',
          content:
            'You are a helpful AI assistant named Ai Intern. ' +
            'Your job is to be of assistance to the user in any way possible.',
        },
        { role: 'assistant', content: 'Hi, how can I help you?' },
        { role: 'user', content: `${enhancedPrompt}` },
      ],
      userId: body.user.id,
      isPaidUser: context.installation.subscription.isActive,
    });
    response = results[0].replace('I am a language model trained by OpenAI', 'I am a language model trained by Hexane');

    await updateTokensUsage({ installation: context.installation, newTokensUsed: tokens });
    await consumeRateLimit({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
      tokens,
    });

    segmentClient.track({
      userId: `${context.teamId}-${body.user.id}`,
      event: 'Intern',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${body.user.id}`,
        prompt: prompt,
        tokens: tokens,
      },
    });

    setResponseInRedis(messageId, response)
    await respond({
      replace_original: true,
      blocks: getTextBlockDraft(prompt, response, messageId),
      text: response,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const imageSendButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const imageUrl = body.actions[0].value;

    // segmentClient.track({
    //   userId: `${context.teamId}-${body.user.id}`,
    //   event: 'Image',
    //   properties: {
    //     groupId: context.teamId,
    //     userId: `${context.teamId}-${body.user.id}`,
    //   },
    // });

    await respond({
      response_type: 'in_channel',
      delete_original: true,
      blocks: getImgBlockFinal(imageUrl, body.user.id),
      text: imageUrl,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const imageRegenerateButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const prompt = body.actions[0].value;
    const openAiImages = await askDallE({
      prompt,
      userId: body.user.id,
      isPaidUser: context.installation.subscription.isActive,
    });
    await updateImagesUsage({ installation: context.installation, newImagesUsed: 1 });
    const imageS3Url = await transferImageToS3(openAiImages[0]);

    segmentClient.track({
      userId: `${context.teamId}-${body.user.id}`,
      event: 'Image',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${body.user.id}`,
        prompt: prompt,
        tokens: 0,
      },
    });

    await respond({
      replace_original: true,
      blocks: getImgBlockDraft(prompt, imageS3Url),
      text: imageS3Url,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const codeSendButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const text = body.actions[0].value;

    // segmentClient.track({
    //   userId: `${context.teamId}-${body.user.id}`,
    //   event: 'Code',
    //   properties: {
    //     groupId: context.teamId,
    //     userId: `${context.teamId}-${body.user.id}`,
    //   },
    // });

    await respond({
      response_type: 'in_channel',
      delete_original: true,
      blocks: getTextBlockFinal(text, body.user.id),
      text: text,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const codeRegenerateButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const prompt = body.actions[0].value;
    let response = '';

    if (typeof preDefinedResponses[prompt.toLowerCase()] !== 'undefined') {
      response = preDefinedResponses[prompt.toLowerCase()];
      await respond({
        replace_original: true,
        blocks: getTextBlockDraft(prompt, response),
        text: response,
      });
      return;
    }

    const rateLimiterMessage = await checkRateLimits({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
    });

    if (rateLimiterMessage) {
      await respond({
        replace_original: true,
        blocks: getRateLimitBlock(rateLimiterMessage),
        text: rateLimiterMessage,
      });
      return;
    }

    const { results, tokens } = await askChatGpt({
      chat: [
        {
          role: 'system',
          content:
            'You are a helpful AI programmer named Ai Intern. ' +
            "Your job is to provide snippets of code to the user about any programming or code related task he asks about. You don't need to explain much.",
        },
        { role: 'assistant', content: 'Hi, how can I help you?' },
        { role: 'user', content: `${prompt}` },
      ],
      userId: body.user.id,
      isPaidUser: context.installation.subscription.isActive,
    });
    response = results[0].replace('I am a language model trained by OpenAI', 'I am a language model trained by Hexane');

    await updateTokensUsage({ installation: context.installation, newTokensUsed: tokens });
    await consumeRateLimit({
      id: context.teamId,
      isSubscriptionActive: context.installation.subscription.isActive,
      tokens,
    });

    segmentClient.track({
      userId: `${context.teamId}-${body.user.id}`,
      event: 'Code',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${body.user.id}`,
        prompt: prompt,
        tokens: tokens,
      },
    });

    await respond({
      replace_original: true,
      blocks: getTextBlockDraft(prompt, response, true),
      text: response,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const cancelButtonCb = async ({ ack, respond, body, context }) => {
  await ack();

  try {
    const messageId = body.actions[0].value;
    await deleteResponseFromRedis(messageId);
    const res = await respond({
      delete_original: true,
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

module.exports.register = app => {
  app.action('button_text_send', textSendButtonCb);
  app.action('button_text_regenerate', textRegenerateButtonCb);
  app.action('button_image_send', imageSendButtonCb);
  app.action('button_image_regenerate', imageRegenerateButtonCb);
  app.action('button_code_send', codeSendButtonCb);
  app.action('button_code_regenerate', codeRegenerateButtonCb);
  app.action('button_cancel', cancelButtonCb);
  app.action('ignore_action', async ({ ack }) => {
    await ack();
  });
};
