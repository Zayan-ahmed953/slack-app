const mongoose = require('mongoose');

const user = mongoose.Schema(
  {
    _id: {
      type: mongoose.Schema.Types.ObjectId,
      auto: true,
    },
    userId: { type: String, required: true, unique: true, index: true },
    localId: { type: String, default: null },
    globalId: { type: String, default: null },
    name: { type: String, default: null },
    username: { type: String, default: null },
    email: { type: String, default: null, index: true },
    phone: { type: String, default: null },
    teamId: { type: String, default: null },
    team: { type: String, default: null },
    meta: {
      isFirstMessage: { type: Boolean, default: true },
    },
  },
  { _id: false, timestamps: true }
);

module.exports.UserModel = mongoose.model('SlackUser', user);
