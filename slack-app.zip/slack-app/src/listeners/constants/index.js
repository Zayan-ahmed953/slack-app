const preDefinedResponses = {
    'hi': 'Hi, how can I help you?',
    'hey': 'Hi, how can I help you?',
    'hello': 'Hi, how can I help you?',
    'hey there': 'Hi, how can I help you?',
    'what\'s up': 'Hi, how can I help you?',
    'whats up': 'Hi, how can I help you?',
    'thanks': 'You are welcome',
    'thank you': 'You are welcome',
    'all right': '',
    'ok': '',
    'yes': '',
    'yeah': '',
    'no': '',
    'bye': '',
    'good bye': '',
    'see you later': '',
    'good morning': '',
    'good night': '',
};

module.exports = {
    preDefinedResponses
};