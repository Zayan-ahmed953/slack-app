const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const { PlansModel } = require('../models/plan');
const { InstallationModel } = require('../models/installation');
const { getManageBlock } = require('../interfaces');
const { segmentClient } = require('../analytics');

const endUserTrial = async installationId => {
  const installation = await InstallationModel.findOneAndUpdate(
    { _id: installationId },
    { trialExpired: true },
    { new: true }
  ).lean();

  if (installation !== undefined) {
    return installation;
  } else {
    throw new Error('Error ending trial');
  }
};

const getPlanDetails = async ({ planName, priceId }) => {
  if (planName) {
    const planDetails = await PlansModel.find({
      name: planName,
      platform: 'Slack',
    }).lean();

    if (planDetails[0] !== undefined) {
      return planDetails[0];
    }
  }

  if (priceId) {
    const planDetails = await PlansModel.find({
      stripePriceId: priceId,
      platform: 'Slack',
    }).lean();

    if (planDetails[0] !== undefined) {
      return planDetails[0];
    }
  }
};

const updateTokensUsage = async ({ installation, newTokensUsed }) => {
  return await InstallationModel.updateOne(
    { _id: installation._id },
    { $inc: { 'usage.tokens': newTokensUsed, 'usage.totalTokensUsed': newTokensUsed } },
    { new: true }
  ).lean();
};

const updateImagesUsage = async ({ installation, newImagesUsed }) => {
  return await InstallationModel.updateOne(
    { _id: installation._id },
    { $inc: { 'usage.images': newImagesUsed, 'usage.totalImagesUsed': newImagesUsed } },
    { new: true }
  ).lean();
};

const setupAdminUserDetails = async ({ installationId, user }) => {
  const installation = await InstallationModel.findOneAndUpdate(
    {
      _id: installationId,
    },
    {
      $set: {
        isAdminUserSetup: true,
        'user.email': user.profile.email,
      },
    },
    { new: true }
  ).lean();

  if (installation !== undefined) {
    return installation;
  } else {
    throw new Error('Error updating admin user info');
  }
};

const createStripeCustomer = async ({ installation }) => {
  const customer = await stripe.customers.create({
    email: installation.user.email,
    metadata: {
      sourceApp: 'Hexane Slack',
    },
  });

  return await InstallationModel.findOneAndUpdate(
    { _id: installation._id },
    { 'subscription.customerId': customer.id },
    { new: true }
  ).lean();
};

const getStripePaymentUrl = async ({ installation, planName }) => {
  const customerID = installation.subscription.customerId;
  const planDetails = await getPlanDetails({ planName });

  const session = await stripe.checkout.sessions.create({
    line_items: [
      {
        price: planDetails.stripePriceId,
        quantity: 1,
      },
    ],
    customer: customerID,
    allow_promotion_codes: true,
    billing_address_collection: 'required',
    metadata: {
      sourceApp: 'Hexane Slack',
    },
    mode: 'subscription',
    success_url: `${process.env.SLACK_APP_LANDING_PAGE}/subscription-successful.html`,
    cancel_url: `${process.env.SLACK_APP_LANDING_PAGE}`,
  });

  return session.url;
};

const getStripePortalUrl = async ({ installation }) => {
  const customerID = installation.subscription.customerId;
  const portalSession = await stripe.billingPortal.sessions.create({
    customer: customerID,
    return_url: process.env.SLACK_APP_LANDING_PAGE,
  });

  return portalSession.url;
};

const sendActivateSubscriptionMessage = async ({
  client,
  installation,
  plan,
  userId,
  channelId,
  actionId,
  hasSubscriptionEnd = false,
  reachedLimitOn = null,
}) => {
  let button = 'Activate Subscription';
  let text = `⚠️ Your ${
    hasSubscriptionEnd ? 'subscription' : 'free trial'
  } has ended. Please activate subscription to continue.`;

  if (reachedLimitOn) {
    button = `Update Subscription`;
    text = `⚠️ You've used all the ${reachedLimitOn} allowed in your current plan. Please update your subscription to continue.`;
  }

  if (userId && channelId && !actionId) {
    await client.chat.postEphemeral({
      channel: channelId,
      user: userId,
      blocks: [
        {
          type: 'header',
          text: {
            type: 'plain_text',
            text: text,
            emoji: true,
          },
        },
      ],
      text: 'Please activate subscription to continue.',
    });

    const stripePortalUrl = await getStripePortalUrl({ installation });
    const stripeCheckOutUrls = {
      individualsPlan: await getStripePaymentUrl({ installation, planName: 'Individuals' }),
      workspacePlan: await getStripePaymentUrl({ installation, planName: 'Workspace' }),
    };

    const manageBlock = getManageBlock({ plan, installation, stripePortalUrl, stripeCheckOutUrls });

    await client.chat.postEphemeral({
      channel: channelId,
      user: userId,
      blocks: manageBlock,
      text: 'Please activate subscription to continue.',
    });
  }
};

const handleStripeEvent = async ({ event }) => {
  let customer;
  let subscription;
  let currentInstallation;

  switch (event.type) {
    case 'customer.created':
    case 'customer.updated':
      customer = event.data.object;
      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': customer.id },
        {
          'user.email': customer.email,
          'user.phone': customer?.phone ? customer.phone : null,
        },
        { new: true }
      ).lean();
      break;

    case 'customer.deleted':
      customer = event.data.object;
      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': customer.id },
        {
          isDeleted: true,
          'subscription.isActive': false,
        },
        { new: true }
      ).lean();
      break;

    case 'customer.subscription.created':
      subscription = event.data.object;
      currentInstallation = await InstallationModel.findOne({
        'subscription.customerId': subscription.customer,
      }).lean();

      const newPlan = await getPlanDetails({ priceId: subscription.items.data[0].price.id });
      if (newPlan.name !== currentInstallation.plan) {
        stripe.subscriptions.del(currentInstallation.subscription.subscriptionId);
      }

      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': subscription.customer },
        {
          'subscription.subscriptionId': subscription.id,
          'subscription.quantity': subscription.quantity,
        },
        { new: true }
      ).lean();
      break;

    case 'customer.subscription.deleted':
    case 'customer.subscription.cancelled':
    case 'customer.subscription.pending_update_expired':
      subscription = event.data.object;
      currentInstallation = await InstallationModel.findOne({
        'subscription.customerId': subscription.customer,
      }).lean();

      // ignore if the cancelled subscription isn't the current subscription
      if (currentInstallation.subscription.subscriptionId !== subscription.id) {
        break;
      }

      await InstallationModel.findOneAndUpdate(
        { 'subscription.customerId': subscription.customer },
        { 'subscription.isActive': false, trialExpired: true },
        { new: true }
      ).lean();
      break;

    case 'customer.subscription.updated':
    case 'customer.subscription.pending_update_applied':
      subscription = event.data.object;
      currentInstallation = await InstallationModel.findOne({
        'subscription.customerId': subscription.customer,
      }).lean();

      if (subscription.status === 'active') {
        const newPlan = await getPlanDetails({ priceId: subscription.items.data[0].price.id });

        const subscriptionUpdates = {
          trialExpired: true,
          'subscription.isActive': true,
          'subscription.subscriptionId': subscription.id,
          'subscription.quantity': subscription.quantity,
          plan: newPlan.name,
          'subscription.lastPaymentDate': subscription.current_period_start,
          'subscription.validityEndDate': subscription.current_period_end,
          'subscription.paymentInterval': subscription.plan.interval,
        };

        if (!subscription.cancel_at_period_end) {
          if (currentInstallation.subscription.validityEndDate < subscription.current_period_end) {
            subscriptionUpdates['usage.images'] = 0;
            subscriptionUpdates['usage.tokens'] = 0;
          }
        }

        await InstallationModel.findOneAndUpdate(
          { 'subscription.customerId': subscription.customer },
          subscriptionUpdates,
          { new: true }
        ).lean();
      }

      if (subscription.status === 'canceled' || subscription.status === 'unpaid') {
        // ignore if the cancelled subscription isn't the current subscription
        if (currentInstallation.subscription.subscriptionId !== subscription.id) {
          break;
        }

        await InstallationModel.findOneAndUpdate(
          { 'subscription.customerId': subscription.customer },
          { 'subscription.isActive': false, trialExpired: true },
          { new: true }
        ).lean();
      }

      break;

    // ... handle other event types
    default:
      // Bugsnag.notify(new Error(`Unhandled event type ${event.type}`));
      console.log(`Unhandled event type ${event.type}`);
  }
};

module.exports = {
  endUserTrial,
  getPlanDetails,
  updateTokensUsage,
  updateImagesUsage,
  setupAdminUserDetails,
  sendActivateSubscriptionMessage,
  createStripeCustomer,
  getStripePaymentUrl,
  getStripePortalUrl,
  handleStripeEvent,
};
