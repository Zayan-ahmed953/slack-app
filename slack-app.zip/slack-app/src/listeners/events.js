const InstallationService = require('../services/installation');
const UserService = require('../services/user');

const { getQuickGuide } = require('../interfaces');
const { segmentClient, Bugsnag } = require('../analytics');
const { wait } = require('../utilities');

const appUninstallEventCb = async ({ client, event, context }) => {
  try {
    const installation = await InstallationService.deleteInstallation({
      enterpriseId: context.enterpriseId,
      teamId: context.teamId,
    });

    segmentClient.track({
      userId: `${context.teamId}-${installation.user.id}`,
      event: 'App Uninstalled',
      properties: {
        groupId: context.teamId,
        userId: `${context.teamId}-${installation.user.id}`,
      },
    });
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

const appHomeOpenedEventCb = async ({ client, event, context, say }) => {
  try {
    // await client.views.publish({
    //   user_id: event.user,
    //   view: {
    //     type: 'home',
    //     blocks: [
    //       {
    //         type: 'section',
    //         text: {
    //           type: 'mrkdwn',
    //           text:
    //             `🎉 Welcome to AI Intern, <@${event.user}>! 🎉 \n\nWrite faster, think bigger, and augment your creativity. ✨ Like magic! ✨` +
    //             `\n\nAlways just a message away, making your workday more efficient and enjoyable. 🚀\n\n`,
    //         },
    //       },
    //       ...getQuickGuide(),
    //     ],
    //   },
    // });

    if (event.tab !== 'messages') return;
    const currentUserId = `${context.teamId}-${event.user}`;
    const currentUser = await UserService.getCurrentUser(currentUserId);
    if (currentUser.meta.isFirstMessage) {
      await UserService.updateFirstMessageCheck(currentUserId);

      await say({
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text:
                `🎉 Welcome to AI Intern, <@${event.user}>! 🎉 \n\nWrite faster, think bigger, and augment your creativity. ✨ Like magic! ✨` +
                `\n\nAlways just a message away, making your workday more efficient and enjoyable. 🚀\n\n`,
            },
          },
          ...getQuickGuide(),
        ],
        text: 'Welcome to AI Intern!',
      });

      await wait(1000);
      await say(`\n Hi, <@${event.user}>! :wave: \n\nI'm your Ai Intern. Don't worry, I may be new to the job, but I'll do my best to assist you better than any human intern ever could. \n\nSo, how can I assist you today?`);
    }
  } catch (error) {
    // Bugsnag.notify(error);
    console.error(error);
  }
};

module.exports.register = app => {
  app.event('app_uninstalled', appUninstallEventCb);
  app.event('app_home_opened', appHomeOpenedEventCb);
};
