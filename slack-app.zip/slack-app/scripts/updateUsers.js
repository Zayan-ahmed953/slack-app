require('dotenv').config();
const mongoose = require('mongoose');

const { UserModel } = require('../src/models/user');
const { segmentClient } = require('../src/analytics');
const axios = require('axios');

// =================================================================================
//                                connect to the db
// =================================================================================

const connectDB = async () => {
  const connection = await mongoose.connect(process.env.MONGODB_URI || '', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  return connection.connection.db;
};

const db = connectDB()
  .then(() => console.log('Database connected successfully\n'))
  .catch(error => {
    // Bugsnag.notify(error);
    throw new Error('\nError connecting to mongodb');
  });

// =================================================================================
//                            thing that needs to get done
// =================================================================================

async function setupAllTeamUsers({ token, teamId, teamName }) {
  let cursor = 0;
  let limit = 50;

  do {
    const response = await axios.get('https://slack.com/api/users.list', {
      headers: { Authorization: `Bearer ${token}` },
      params: { cursor, limit, team_id: `${teamId}` },
    });

    cursor = response.data.response_metadata.next_cursor;
    for (const user of response.data.members) {
      if (user.is_bot || user.name === 'slackbot') continue;

      await UserModel.findOneAndUpdate(
        { userId: `${teamId}-${user.id}` },
        {
          userId: `${teamId}-${user.id}`,
          localId: user.id,
          globalId: null,
          name: user.real_name || user.name,
          username: user.name,
          email: user.profile.email,
          phone: null,
          teamId: teamId,
          team: teamName,
        },
        { upsert: true }
      ).lean();

      segmentClient.identify({
        userId: `${teamId}-${user.id}`,
        traits: {
          userId: `${teamId}-${user.id}`,
          groupId: teamId,
          team: teamName,
          username: user.name,
          name: user.real_name || user.name,
          email: user.profile.email,
        },
      });
    }
  } while (cursor !== '');
}

setupAllTeamUsers({
  token: 'xoxb-955338377360-5066312514436-dZnly4IYTiLN0leFYz93MRtT',
  teamId: 'TU39YB3AL',
  teamName: 'esparks',
}).then(() => console.log('Done'));
